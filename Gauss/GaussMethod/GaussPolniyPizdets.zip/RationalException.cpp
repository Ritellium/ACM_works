#include "RationalException.h"

const RationalException RationalException::div_zero("division by zero!");
const RationalException RationalException::prec_err("too much precision!");